import * as React from "react";

export const MainComponent = (props: any) => {
    return (
        <div style={{ padding: "12px", border: "1px solid #ccc", borderRadius: "6px" }}>
            <h3>Advanced Calendar PCF with multi-date and range selection</h3>
            <p>This is a PCF starter component.</p>
        </div>
    );
};
